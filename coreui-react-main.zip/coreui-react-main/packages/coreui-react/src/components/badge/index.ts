import { CBadge } from './CBadge'

export { CBadge }
