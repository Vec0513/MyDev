import { CImage } from './CImage'

export { CImage }
