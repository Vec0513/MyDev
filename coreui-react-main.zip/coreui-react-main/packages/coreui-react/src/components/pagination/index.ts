import { CPagination } from './CPagination'
import { CPaginationItem } from './CPaginationItem'

export { CPagination, CPaginationItem }
