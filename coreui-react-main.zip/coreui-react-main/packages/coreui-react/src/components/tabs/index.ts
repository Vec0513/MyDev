import { CTab } from './CTab'
import { CTabContent } from './CTabContent'
import { CTabPane } from './CTabPane'
import { CTabPanel } from './CTabPanel'
import { CTabList } from './CTabList'
import { CTabs } from './CTabs'

export { CTab, CTabContent, CTabList, CTabPane, CTabPanel, CTabs }
