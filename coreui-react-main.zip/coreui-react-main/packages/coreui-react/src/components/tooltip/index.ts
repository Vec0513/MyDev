import { CTooltip } from './CTooltip'

export { CTooltip }
