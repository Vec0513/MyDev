import { CWidgetStatsA } from './CWidgetStatsA'
import { CWidgetStatsB } from './CWidgetStatsB'
import { CWidgetStatsC } from './CWidgetStatsC'
import { CWidgetStatsD } from './CWidgetStatsD'
import { CWidgetStatsE } from './CWidgetStatsE'
import { CWidgetStatsF } from './CWidgetStatsF'

export { CWidgetStatsA, CWidgetStatsB, CWidgetStatsC, CWidgetStatsD, CWidgetStatsE, CWidgetStatsF }
